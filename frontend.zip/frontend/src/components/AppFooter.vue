<template>
    <footer class="bg-light py-3 mt-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12" style="text-align: center">
            &copy; 2025 Nike-C'Neva. Все права защищены.
          </div>
        </div>
      </div>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'AppFooter',
  };
  </script>
  
  <style scoped>
  /* Стили для футера */
  </style>
   